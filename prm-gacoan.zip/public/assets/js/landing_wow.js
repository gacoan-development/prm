wow = new WOW({
    mobile: false
})
wow.init();