        <footer class="footer">
          <div class="container-fluid">
            <div class="row">
              <div class="col-md-6 p-0 footer-left">
                <p class="mb-0">Copyright © 2024 PPA-Parking Revenue Monitoring . All rights reserved.</p>
              </div>
              <div class="col-md-6 p-0 footer-right">
                <ul class="color-varient">
                <p class="mb-0 ms-3">Mie Gacoan<i class="fa fa-heart font-danger"></i></p>
              </div>
            </div>
          </div>
        </footer>